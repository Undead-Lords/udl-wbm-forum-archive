<!DOCTYPE html>
	<html lang="en"  xmlns:fb="http://www.facebook.com/2008/fbml">
	<head>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="http://forums.undeadlords.net/public/style_images/Underground/_cache/Platform.js"></script>
		<meta charset="UTF-8" />
		<title>The Undead Lords</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<link rel="shortcut icon" href='http://forums.undeadlords.net/favicon.ico' />
		<link rel="image_src" href='http://forums.undeadlords.net/public/style_images/Underground/meta_image.png' />
		<script type='text/javascript'>
		//<![CDATA[
			jsDebug			= 0; /* Must come before JS includes */
			DISABLE_AJAX	= parseInt(0); /* Disables ajax requests where text is sent to the DB; helpful for charset issues */
			inACP			= false;
			var isRTL		= false;
			var rtlIe		= '';
			var rtlFull		= '';
		//]]>
		</script>
		
	
				
	

				
	

				
	

				
	

				
	

				
	
	
		<link rel="stylesheet" type="text/css" media='screen,print' href="http://forums.undeadlords.net/public/min/index.php?ipbv=8159b316e2acaa9b5d977d18291cb2e4&amp;f=public/style_css/css_18/ipb_help.css,public/style_css/css_18/skinbox.css,public/style_css/css_18/ipb_common.css,public/style_css/css_18/ipb_styles.css,public/style_css/css_18/calendar_select.css,public/style_css/css_18/ipshoutbox.css" />
	

<!--[if lte IE 7]>
	<link rel="stylesheet" type="text/css" title='Main' media="screen" href="http://forums.undeadlords.net/public/style_css/css_18/ipb_ie.css" />
<![endif]-->
<!--[if lte IE 8]>
	<style type='text/css'>
		.ipb_table { table-layout: fixed; }
		.ipsLayout_content { width: 99.5%; }
	</style>
<![endif]-->

	<style type='text/css'>
		img.bbc_img { max-width: 100% !important; }
	</style>
<style type="text/css">
	#ipboard_body .main_width, .width, .wrapper { width: 100% !important; min-width: 980px !important; }
.sb-avatar-frame, .sb-avatar-frame img { width: 40px; height: 40px; }
.sb-avatar-frame-in-forums, .sb-avatar-frame-in-forums img { width: 40px; height: 40px; }
.sb-avatar-frame-in-topics, .sb-avatar-frame-in-topics img { width: 40px; height: 40px; }

</style>
		<link href='http://fonts.googleapis.com/css?family=Raleway:100' rel='stylesheet' type='text/css'>
<meta property="og:title" content="The Undead Lords"/>
		<meta property="og:site_name" content="The Undead Lords"/>
		<meta property="og:type" content="article" />

		
	
		
		
			<meta name="identifier-url" content="http://forums.undeadlords.net/index.php?act=task" />
		
		
			<meta property="og:url" content="http://forums.undeadlords.net/index.php?act=task" />
		
		
		
	

<meta property="og:image" content="http://forums.undeadlords.net/public/style_images/Underground/meta_image.png"/>
		
		
		<script type='text/javascript' src="http://forums.undeadlords.net/public/style_images/Underground/js/skinbox.js"></script>
		
		<script type='text/javascript' src='http://forums.undeadlords.net/public/min/index.php?ipbv=8159b316e2acaa9b5d977d18291cb2e4&amp;g=js'></script>
	
	<script type='text/javascript' src='http://forums.undeadlords.net/public/min/index.php?ipbv=8159b316e2acaa9b5d977d18291cb2e4&amp;charset=UTF-8&amp;f=public/js/ipb.js,cache/lang_cache/1/ipb.lang.js,public/js/ips.hovercard.js,public/js/ips.quickpm.js,public/js/ips.board.js' charset='UTF-8'></script>


	
		
			
			
			
			
				<link id="ipsCanonical" rel="canonical" href="http://forums.undeadlords.net/index.php?act=idx" />
			
		
	

		
			
			
				<link rel="alternate" type="application/rss+xml" title="news" href="http://forums.undeadlords.net/index.php?app=core&amp;module=global&amp;section=rss&amp;type=forums&amp;id=4" />
			
			
			
		

			
			
				<link rel="alternate" type="application/rss+xml" title="Community Calendar" href="http://forums.undeadlords.net/index.php?app=core&amp;module=global&amp;section=rss&amp;type=calendar&amp;id=1" />
			
			
			
		
	

	



		
		<script type='text/javascript'>
	//<![CDATA[
		/* ---- URLs ---- */
		ipb.vars['base_url'] 			= 'http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&';
		ipb.vars['board_url']			= 'http://forums.undeadlords.net';
		ipb.vars['img_url'] 			= "http://forums.undeadlords.net/public/style_images/Underground";
		ipb.vars['loading_img'] 		= 'http://forums.undeadlords.net/public/style_images/Underground/loading.gif';
		ipb.vars['active_app']			= 'forums';
		ipb.vars['upload_url']			= 'http://forums.undeadlords.net/uploads';
		/* ---- Member ---- */
		ipb.vars['member_id']			= parseInt( 0 );
		ipb.vars['is_supmod']			= parseInt( 0 );
		ipb.vars['is_admin']			= parseInt( 0 );
		ipb.vars['secure_hash'] 		= '880ea6a14ea49e853634fbdc5015a024';
		ipb.vars['session_id']			= '4706588342511bb6d5e4db3cb505f0d8';
		ipb.vars['twitter_id']			= 0;
		ipb.vars['fb_uid']				= 0;
		ipb.vars['auto_dst']			= parseInt( 0 );
		ipb.vars['dst_in_use']			= parseInt(  );
		ipb.vars['is_touch']			= false;
		ipb.vars['member_group']		= {"g_mem_info":"0"}
		/* ---- cookies ----- */
		ipb.vars['cookie_id'] 			= 'udl_owns';
		ipb.vars['cookie_domain'] 		= 'undeadlords.net';
		ipb.vars['cookie_path']			= '/';
		/* ---- Rate imgs ---- */
		ipb.vars['rate_img_on']			= 'http://forums.undeadlords.net/public/style_images/Underground/star.png';
		ipb.vars['rate_img_off']		= 'http://forums.undeadlords.net/public/style_images/Underground/star_off.png';
		ipb.vars['rate_img_rated']		= 'http://forums.undeadlords.net/public/style_images/Underground/star_rated.png';
		/* ---- Uploads ---- */
		ipb.vars['swfupload_swf']		= 'http://forums.undeadlords.net/public/js/3rd_party/swfupload/swfupload.swf';
		ipb.vars['swfupload_enabled']	= true;
		ipb.vars['use_swf_upload']		= ( '' == 'flash' ) ? true : false;
		ipb.vars['swfupload_debug']		= false;
		/* ---- other ---- */
		ipb.vars['highlight_color']     = "#ade57a";
		ipb.vars['charset']				= "UTF-8";
		ipb.vars['time_offset']			= "-5";
		ipb.vars['hour_format']			= "12";
		ipb.vars['seo_enabled']			= 0;
		
		/* Templates/Language */
		ipb.templates['inlineMsg']		= "";
		ipb.templates['ajax_loading'] 	= "<div id='ajax_loading'><img src='http://forums.undeadlords.net/public/style_images/Underground/ajax_loading.gif' alt='" + ipb.lang['loading'] + "' /></div>";
		ipb.templates['close_popup']	= "<img src='http://forums.undeadlords.net/public/style_images/Underground/close_popup.png' alt='x' />";
		ipb.templates['rss_shell']		= new Template("<ul id='rss_menu' class='ipbmenu_content'>#{items}</ul>");
		ipb.templates['rss_item']		= new Template("<li><a href='#{url}' title='#{title}'>#{title}</a></li>");
		
		ipb.templates['autocomplete_wrap'] = new Template("<ul id='#{id}' class='ipb_autocomplete' style='width: 250px;'></ul>");
		ipb.templates['autocomplete_item'] = new Template("<li id='#{id}' data-url='#{url}'><img src='#{img}' alt='' class='ipsUserPhoto ipsUserPhoto_mini' />&nbsp;&nbsp;#{itemvalue}</li>");
		ipb.templates['page_jump']		= new Template("<div id='#{id}_wrap' class='ipbmenu_content'><h3 class='bar'>Jump to page</h3><p class='ipsPad'><input type='text' class='input_text' id='#{id}_input' size='8' /> <input type='submit' value='Go' class='input_submit add_folder' id='#{id}_submit' /></p></div>");
		ipb.templates['global_notify'] 	= new Template("<div class='popupWrapper'><div class='popupInner'><div class='ipsPad'>#{message} #{close}</div></div></div>");
		
		
		ipb.templates['header_menu'] 	= new Template("<div id='#{id}' class='ipsHeaderMenu boxShadow'></div>");
		
		Loader.boot();
	//]]>
	</script>
	</head>
	<body id='ipboard_body' class=" feature-dropdowns-on">
		<p id='content_jump' class='hide'><a href='#j_content' title='Jump to content' accesskey='m'>Jump to content</a></p>
		<div id='ipbwrapper'>
        <div class="width">
			<div class="border-left"><div class="border-right">
			<!-- ::: BRANDING STRIP: Logo and search box ::: -->
			<div id='branding' class='clearfix'>
                <div id='logo'>
                    
                        <a href='http://forums.undeadlords.net' title='Go to community index' rel="home" accesskey='1'><img src='http://forums.undeadlords.net/public/style_images/Underground/logo.png' alt='Logo' /></a>
                    
                </div>
                
                <!-- ::: APPLICATION TABS ::: -->
		<div id='primary_nav' class='clearfix'>
                <ul class='ipsList_inline' id='community_app_menu'>
                    
                        <li id='nav_home' class='left'><a href='http://www.undeadlords.net/' title='Homepage' rel="home">The Undead Lords</a></li>
                    
                    
                        
                            
                        

                            
                                                                <li id='nav_app_forums' class="left active"><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;act=idx' title='Go to Forums'>Forums</a></li>
                            
                        

                            
                                                                <li id='nav_app_members' class="left "><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=members&amp;module=list' title='Go to Members'>Members</a></li>
                            
                        

                            
                                                                <li id='nav_app_subscriptions' class="left "><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=subscriptions' title='Go to UDL Support'>UDL Support</a></li>
                            
                        

                            
                                                                <li id='nav_app_calendar' class="left "><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=calendar' title='Go to Calendar'>Calendar</a></li>
                            
                        

                            
                                                                <li id='nav_app_shoutbox' class="left "><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=shoutbox' title='Go to Shoutbox'>Shoutbox</a></li>
                            
                        

                            
                                                                <li id='nav_app_livestreams' class="left "><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams' title='Go to Live Streams'>Live Streams</a></li>
                            
                        
                    
		    <li id="nav_more" data-dropdown>
			<a href="#">More <img src="http://forums.undeadlords.net/public/style_images/Underground/_custom/dropdown_arrow.png" alt="" /></a>
			<ul>
				<li><a href="http://www.twitter.com/username"><img src="http://forums.undeadlords.net/public/style_images/Underground/_custom/icon-social_twitter.png" alt="" /> Follow Us on Twitter</a></li>
				<li><a href="http://www.facebook.com/page"><img src="http://forums.undeadlords.net/public/style_images/Underground/_custom/icon-social_facebook.png" alt="" /> Like Us on Facebook</a></li>
				<li><a href="http://www.youtube.com/page"><img src="http://forums.undeadlords.net/public/style_images/Underground/_custom/icon-social_youtube.png" alt="" /> Subscribe on Youtube</a></li>
			</ul>
	            </li>
                    <li id='nav_other_apps' style='display: none'>
                        <a href='#' class='ipbmenu' id='more_apps'>More <img src='http://forums.undeadlords.net/public/style_images/Underground/useropts_arrow.png' /></a>
                    </li>
                </ul>
		</div>
                
			</div>
            
            <div id='user_bar' class='clearfix'>
            
            	<div id='user_navigation' class='not_logged_in'>
                        
                        <ul class='ipsList_inline'>
                            <li>
                                <span class='services'>
                                    
                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=login&amp;serviceClick=facebook'><img src='http://forums.undeadlords.net/public/style_images/Underground/loginmethods/facebook.png' alt='Log in with Facebook' /></a>
                                    
                                    
                                    
                                </span>
                                <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=login' title='Sign In' id='sign_in'><img src="http://forums.undeadlords.net/public/style_images/Underground/user_login.png" alt="" /> Sign In</a>
                            </li>
                            <li>
                                <a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=register" title='Create Account' id='register_link'><img src="http://forums.undeadlords.net/public/style_images/Underground/user_register.png" alt="" /> Create Account</a>
                            </li>
                        </ul>
                    </div>
            
				<div id='search' class='right'>
	<form action="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=search&amp;do=search&amp;fromMainBar=1" method="post" id='search-box' >
		<fieldset>
			<label for='main_search' class='hide'>Search</label>
			<a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=search&amp;search_in=forums' title='Advanced Search' accesskey='4' rel="search" id='adv_search' class='right'>Advanced</a>
			<span id='search_wrap' class='right'>
				<input type='text' id='main_search' name='search_term' class='inactive' size='17' tabindex='100' />
				<span class='choice ipbmenu clickable' id='search_options' style='display: none'></span>
				<ul id='search_options_menucontent' class='ipbmenu_content ipsPad' style='display: none'>
					<li class='title'><strong>Search section:</strong></li>
					
					
					
					<li class='app'><label for='s_forums' title='Forums'><input type='radio' name='search_app' class='input_radio' id='s_forums' value="forums" checked="checked" />Forums</label></li>
					<li class='app'><label for='s_members' title='Members'><input type='radio' name='search_app' class='input_radio' id='s_members' value="members"  />Members</label></li>
					<li class='app'><label for='s_core' title='Help Files'><input type='radio' name='search_app' class='input_radio' id='s_core' value="core"  />Help Files</label></li>
					
						
					

						
					

						
					

						
					

						<li class='app'>
								<label for='s_calendar' title='Calendar'>
									<input type='radio' name='search_app' class='input_radio' id='s_calendar' value="calendar"  />Calendar
								</label>
							</li>
					

						
					

						
					
				</ul>
				<input type='submit' class='submit_input clickable' value='Search' />
			</span>
			
		</fieldset>
	</form>
</div>
                       
            </div>
<div class='content'>
			<!-- ::: MAIN CONTENT AREA ::: -->
			<div id='content' class='clearfix'>

				<!-- ::: NAVIGATION BREADCRUMBS ::: -->

					<div id='secondary_navigation' class='clearfix'>
                    
						<ol class='breadcrumb top ipsList_inline left' id='breadcrumb'>
														<li itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class='first'>
									<a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;act=idx' itemprop="url">
										<span itemprop="title">The Undead Lords</span>
									</a>
								</li>
								
													</ol>
                        
                        <ul id='secondary_links' class='ipsList_inline right'>
                        <li><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=forums&amp;module=extras&amp;section=boardrules'>UDL</a></li>
                        <li><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=search&amp;do=viewNewContent&amp;search_app=forums' accesskey='2'>View New Content</a></li>
                        
                        <li><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=navigation&amp;inapp=forums" rel="quickNavigation" accesskey='9' id='quickNavLaunch' title="Open Quick Navigation"><img src="http://forums.undeadlords.net/public/style_images/Underground/icon_quicknav.png" alt="" /></a></li>
                        
						</ul>
                    
					</div>


				
				<!-- ::: CONTENT ::: -->

                <noscript>
                    <div class='message error'>
                        <strong>Javascript Disabled Detected</strong>
                        <p>You currently have javascript disabled. Several functions may not work. Please re-enable javascript to access full functionality.</p>
                    </div>
                    <br />
                </noscript>

				
				
<div id='board_index' class='ipsLayout ipsLayout_withright ipsLayout_largeright clearfix '>	
	<div id='categories' class='ipsLayout_content clearfix'>
	<!-- CATS AND FORUMS -->
		
			
				<div id='category_17' class='category_block block_wrap'>
						<h3 class='maintitle'>
							<a class='toggle right' href='#' title="Toggle Public Area">Toggle Public Area</a> <a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=17" title='View Public Area'>Public Area</a>
						</h3><div class='border'>
						<div class='ipsBox table_wrap removeDefault'>
							<div class='ipsBox_container'>
								<table class='ipb_table' summary="Forums within the category 'Public Area'">
									<tr class='header hide'>
										<th scope='col' class='col_c_forum'>Forum</th>
										<th scope='col' class='col_c_stats stats'>Stats</th>
										<th scope='col' class='col_c_post'>Last Post Info</th>
									</tr>
									<!-- / CAT HEADER -->
									
										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=93" title='News and Announcements'>News and Announcements</a></strong>
													</h4> 

																								

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>30 topics</li>
														<li>3 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3321.jpg?_r=1357314526' alt='The Elder Scrolls Online Gu... - last post by Scribe' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=21901' title='The Elder Scrolls Online Guild:  Undead Lords [UDL]'>The Elder Scrolls Online Gu...</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=21901&amp;view=getlastpost' title='View last post'>13 Feb 2014</a>
                                                                    </span>
                                                                    
                                                                        By 
	Scribe

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=109" title='Apply to the Undead Lords'>Apply to the Undead Lords</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>This is a forum for mortals seeking to serve the Dark Lord to apply to UDL.</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>56 topics</li>
														<li>146 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3607.jpg?_r=1395858133' alt='Wheelz - ESO Application - last post by Wheelz' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22335' title='Wheelz - ESO Application'>Wheelz - ESO Application</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22335&amp;view=getlastpost' title='View last post'>Today, 02:13 PM</a>
                                                                    </span>
                                                                    
                                                                        By 
	Wheelz

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=2" title='General Chat'>General Chat</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Public access forum for visitors, worshippers, followers, maggots, and breather allies in all realms that His army roams and collects souls.</p>											

													
														<ol class='ipsList_inline ipsType_small subforums' id='subforums_2'>
															
																<li>
																	<a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=217" title='Download Mumble Here'>Download Mumble Here</a>
																</li>
															
														</ol>
													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>422 topics</li>
														<li>2,983 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://www.gravatar.com/avatar/369a1ae89521386f7d570bf48eac0f69?s=100&amp;d=http%3A%2F%2Fforums.undeadlords.net%2Fpublic%2Fstyle_images%2FUnderground%2Fprofile%2Fdefault_large.png' alt='Need UDL Mumble Access? - last post by Joras' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22048' title='Need UDL Mumble Access?'>Need UDL Mumble Access?</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22048&amp;view=getlastpost' title='View last post'>Today, 12:59 PM</a>
                                                                    </span>
                                                                    
                                                                        By 
	Joras

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=3" title='Flame Board'>Flame Board</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'> Hate us? Hate them? Let it out! (Low moderation, parents beware)</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>106 topics</li>
														<li>1,274 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3399.jpg?_r=1364359761' alt='Zers&#39; Monolithic Freak... - last post by Kick' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=5466' title='Zers&#39; Monolithic Freak show'>Zers&#39; Monolithic Freak...</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=5466&amp;view=getlastpost' title='View last post'>Today, 01:14 PM</a>
                                                                    </span>
                                                                    
                                                                        By 
	Kick

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=4" title='Story Board'>Story Board</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Allow your persona to take control. Weave fantastic stories as they pertain in your online game world. (This board is heavily moderated.)</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>35 topics</li>
														<li>115 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3078.jpg?_r=0' alt='The Path of Krang - last post by noxii' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=17469' title='The Path of Krang'>The Path of Krang</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=17469&amp;view=getlastpost' title='View last post'>04 Dec 2013</a>
                                                                    </span>
                                                                    
                                                                        By 
	noxii

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=107" title='Alpha Beta Central'>Alpha Beta Central</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>A forum for UDL and Allies to discuss upcoming games</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>92 topics</li>
														<li>996 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://www.gravatar.com/avatar/6f4f33e1928252c125dee866e1c234f8?s=100&amp;d=http%3A%2F%2Fforums.undeadlords.net%2Fpublic%2Fstyle_images%2FUnderground%2Fprofile%2Fdefault_large.png' alt='Das Tal - PvP Sandbox MMO i... - last post by Emissary' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=21982' title='Das Tal - PvP Sandbox MMO in development'>Das Tal - PvP Sandbox MMO i...</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=21982&amp;view=getlastpost' title='View last post'>Yesterday, 09:41 PM</a>
                                                                    </span>
                                                                    
                                                                        By 
	Emissary

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=115" title='Quick Fix Games'>Quick Fix Games</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Limited time? Need a break from the grind? Catch up with kin and game for an hour or two! Organize a non-MMO gaming night here.  Open to Knights, recruits and allies</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>256 topics</li>
														<li>1,733 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://www.gravatar.com/avatar/451688cad4539fba33d2e637c9102d7c?s=100&amp;d=http%3A%2F%2Fforums.undeadlords.net%2Fpublic%2Fstyle_images%2FUnderground%2Fprofile%2Fdefault_large.png' alt='Smite - last post by kager' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=18546' title='Smite'>Smite</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=18546&amp;view=getlastpost' title='View last post'>23 Mar 2014</a>
                                                                    </span>
                                                                    
                                                                        By 
	kager

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									
								</table>
							</div>
						</div></div>
						<br />
					</div>
			

				<div id='category_209' class='category_block block_wrap'>
						<h3 class='maintitle'>
							<a class='toggle right' href='#' title="Toggle Elder Scrolls Online">Toggle Elder Scrolls Online</a> <a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=209" title='View Elder Scrolls Online'>Elder Scrolls Online</a>
						</h3><div class='border'>
						<div class='ipsBox table_wrap removeDefault'>
							<div class='ipsBox_container'>
								<table class='ipb_table' summary="Forums within the category 'Elder Scrolls Online'">
									<tr class='header hide'>
										<th scope='col' class='col_c_forum'>Forum</th>
										<th scope='col' class='col_c_stats stats'>Stats</th>
										<th scope='col' class='col_c_post'>Last Post Info</th>
									</tr>
									<!-- / CAT HEADER -->
									
										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=212" title='Elder Scrolls Online Public Forum'>Elder Scrolls Online Public Forum</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>This forum is a public forum for the discussion of Elder Scrolls Online</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>54 topics</li>
														<li>339 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-59.jpg?_r=1367000594' alt='Becket Joining - last post by Savante' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22295' title='Becket Joining'>Becket Joining</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22295&amp;view=getlastpost' title='View last post'>Yesterday, 02:22 PM</a>
                                                                    </span>
                                                                    
                                                                        By 
	Savante

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									
								</table>
							</div>
						</div></div>
						<br />
					</div>
			

				<div id='category_205' class='category_block block_wrap'>
						<h3 class='maintitle'>
							<a class='toggle right' href='#' title="Toggle General Games">Toggle General Games</a> <a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=205" title='View General Games'>General Games</a>
						</h3><div class='border'>
						<div class='ipsBox table_wrap removeDefault'>
							<div class='ipsBox_container'>
								<table class='ipb_table' summary="Forums within the category 'General Games'">
									<tr class='header hide'>
										<th scope='col' class='col_c_forum'>Forum</th>
										<th scope='col' class='col_c_stats stats'>Stats</th>
										<th scope='col' class='col_c_post'>Last Post Info</th>
									</tr>
									<!-- / CAT HEADER -->
									
										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=207" title='Guild Wars 2 Discussion'>Guild Wars 2 Discussion</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Discussion for all things related to Guild Wars 2.</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>8 topics</li>
														<li>60 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
                                                        
	<div class='left'>

<img src='http://www.gravatar.com/avatar/8840012ee67d75376678ca9487a71648?s=100&amp;d=http%3A%2F%2Fforums.undeadlords.net%2Fpublic%2Fstyle_images%2FUnderground%2Fprofile%2Fdefault_large.png' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

                                                        
														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><i>Protected Forum</i></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        04 Feb 2014
                                                                    </span>
                                                                    
                                                                        By 
	Lord Groone

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=204" title='EverQuest Next/Landmark'>EverQuest Next/Landmark</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Discussion for all things related to EverQuest Next Landmark and EverQuest Next.  The game is currently under NDA so this is not a public access forum.</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>57 topics</li>
														<li>167 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
                                                        
	<div class='left'>

<img src='http://www.gravatar.com/avatar/8840012ee67d75376678ca9487a71648?s=100&amp;d=http%3A%2F%2Fforums.undeadlords.net%2Fpublic%2Fstyle_images%2FUnderground%2Fprofile%2Fdefault_large.png' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

                                                        
														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><i>Protected Forum</i></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        21 Mar 2014
                                                                    </span>
                                                                    
                                                                        By 
	Lord Groone

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=213" title='League of Legends'>League of Legends</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Public discussion forum for League of Legends</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>4 topics</li>
														<li>53 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3399.jpg?_r=1364359761' alt='our ranked team - last post by Kick' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22288' title='our ranked team'>our ranked team</a></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        <a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22288&amp;view=getlastpost' title='View last post'>Yesterday, 02:24 PM</a>
                                                                    </span>
                                                                    
                                                                        By 
	Kick

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									

										<tr class='notnew'>
												<td class='col_c_forum'>
													
													<h4>
														
														<strong class='highlight_unread'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showforum=214" title='UO An Corp'>UO An Corp</a></strong>
													</h4> 

													<p class='desc __forum_desc forum_desc ipsType_small'>Akasha's forum of talking about things UO until ESO is out.</p>											

													
																					
												</td>
												<td class='col_c_stats ipsType_small'>
													<ul>
														<li>71 topics</li>
														<li>418 replies</li>
													</ul>
												</td>
												<td class='col_c_post'>
													
                                                        
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3593.gif?_r=1395811436' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

                                                        
														<ul class='last_post ipsType_small'>
															<li>
																	<strong class='highlight_unread'><i>Protected Forum</i></strong>
																</li>
                                                                <li>
                                                                    <span class='desc lighter blend_links'>
                                                                    
                                                                        Yesterday, 05:41 PM
                                                                    </span>
                                                                    
                                                                        By 
	Budikah

                                                                    
                                                                </li>
															
														</ul>
												</td>
											</tr>
									
								</table>
							</div>
						</div></div>
						<br />
					</div>
			
		
	</div>
	<div id='index_stats' class='ipsLayout_right clearfix' >
			<style type='text/css'>
.block-live__list { list-style: none; margin: 0; padding: 0; }
.block-live__list-item { position: relative; padding: 2px 0; }
.block-live__tooltip { width: 350px; opacity: 0; margin: 0; position: absolute; z-index: 10; top: -9px; left: -350px; }
.block-live__tooltip .popupInner { width: 100%; position: relative; min-height: 160px; max-height: 550px; }
.block-live__link { display: block; height: 26px; }
.block-live__list-item__name { float: left; }
.block-live__list-item__online, .block-live__list-item__viewers { float: right; }
.block-live__list-item__viewers { margin-right: 10px; }
.block-live__tooltip-arrow { width: 0px; height: 0px; right: -6px; position: absolute; top: 10px; border-style: solid;border-width: 4px 0 4px 6px;border-color: rgba(0, 0, 0, 0) rgba(0, 0, 0, 0) rgba(0, 0, 0, 0) #041E2C; }
.block-live__tooltip-preview .ipsUserPhoto { width: 77px; }
.block-live__tooltip-preview .rating {
	margin-top: 0;
    margin-left: -2px;
}
.block-live__tooltip-preview .rating img {
    float: left;
    margin-left: 1px;
}
.block-live__tooltip-right { padding: 8px 8px 20px 95px;/* min-height: 72px;*/ }
.block-live__tooltip-status, .block-live__tooltip-about { margin-bottom: 6px; }
.block-live__tooltip-submitted { padding: 8px 10px; }
.streamsHover h3 { padding-left: 105px; }
</style>

	<div class="block-live">
		<div class="ipsSideBlock clearfix">
			<h3 id="anonymous_element_49">LIVE STREAMS</h3> 
			<ul class="block-live__list">
				
					<li stream_id="1" class="block-live__list-item">
						<a id="hover-card-link-1" hovercard-id="1" hovercard-ref="streamHoverCards" class="block-live__link _hovertrigger" href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=1">
							<div class='block-live__list-item__online'>
								
									<img src='http://forums.undeadlords.net/public/style_images/Underground/rep_down.png' alt='-' />
								
							</div>
							<div class="block-live__list-item__viewers">0</div>
							<div class="block-live__list-item__name">Saurkor</div>
						</a>
					</li>
					<div class='live-stream-1 block-live__tooltip popupWrapper' style='display: none;'>
						<div class='popupInner userpopup'>
							<h3><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=1">Saurkor</a></h3>
							<div class='block-live__tooltip-preview side left ipsPad'>
								<div style='margin-bottom: 6px;'><img class='ipsUserPhoto' src='http://static-cdn.jtvnw.net/ttv-boxart/League of Legends.jpg' alt='League of Legends' title='League of Legends' /></div>
								<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class='rating ipsType_smaller'>
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
								</span>
							</div>
							<div class='block-live__tooltip-right'>
								
									<div class='message' style='margin-bottom:5px;'>
										<div class='block-live__tooltip-status'>Saurkor with Sivir, please increase my viewers and followers!!!! #LeagueofLegends @twitch</div>
									</div>
								
								<div class="info">			
									<dl>
										<dt>Online For</dt>
											<dd>0</dd>
										<dt>Submitted by</dt>
											<dd>Lord Groone</dd>
										<dt>Comments</dt>
											<dd>0</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				

					<li stream_id="2" class="block-live__list-item">
						<a id="hover-card-link-2" hovercard-id="2" hovercard-ref="streamHoverCards" class="block-live__link _hovertrigger" href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=2">
							<div class='block-live__list-item__online'>
								
									<img src='http://forums.undeadlords.net/public/style_images/Underground/rep_down.png' alt='-' />
								
							</div>
							<div class="block-live__list-item__viewers">0</div>
							<div class="block-live__list-item__name">LordKick</div>
						</a>
					</li>
					<div class='live-stream-2 block-live__tooltip popupWrapper' style='display: none;'>
						<div class='popupInner userpopup'>
							<h3><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=2">LordKick</a></h3>
							<div class='block-live__tooltip-preview side left ipsPad'>
								<div style='margin-bottom: 6px;'><img class='ipsUserPhoto' src='http://static-cdn.jtvnw.net/ttv-boxart/League of Legends.jpg' alt='League of Legends' title='League of Legends' /></div>
								<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class='rating ipsType_smaller'>
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
								</span>
							</div>
							<div class='block-live__tooltip-right'>
								
									<div class='message' style='margin-bottom:5px;'>
										<div class='block-live__tooltip-status'>Kick in some Ranked Yolo Queue</div>
									</div>
								
								<div class="info">			
									<dl>
										<dt>Online For</dt>
											<dd>0</dd>
										<dt>Submitted by</dt>
											<dd>Lord Groone</dd>
										<dt>Comments</dt>
											<dd>0</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				

					<li stream_id="3" class="block-live__list-item">
						<a id="hover-card-link-3" hovercard-id="3" hovercard-ref="streamHoverCards" class="block-live__link _hovertrigger" href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=3">
							<div class='block-live__list-item__online'>
								
									<img src='http://forums.undeadlords.net/public/style_images/Underground/rep_down.png' alt='-' />
								
							</div>
							<div class="block-live__list-item__viewers">0</div>
							<div class="block-live__list-item__name">IcemanUDL</div>
						</a>
					</li>
					<div class='live-stream-3 block-live__tooltip popupWrapper' style='display: none;'>
						<div class='popupInner userpopup'>
							<h3><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=3">IcemanUDL</a></h3>
							<div class='block-live__tooltip-preview side left ipsPad'>
								<div style='margin-bottom: 6px;'><img class='ipsUserPhoto' src='http://static-cdn.jtvnw.net/ttv-boxart/The Elder Scrolls Online.jpg' alt='The Elder Scrolls Online' title='The Elder Scrolls Online' /></div>
								<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class='rating ipsType_smaller'>
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
								</span>
							</div>
							<div class='block-live__tooltip-right'>
								
									<div class='message' style='margin-bottom:5px;'>
										<div class='block-live__tooltip-status'>Hey Look ESO is up right now for testing!</div>
									</div>
								
								<div class="info">			
									<dl>
										<dt>Online For</dt>
											<dd>0</dd>
										<dt>Submitted by</dt>
											<dd>Lord Groone</dd>
										<dt>Comments</dt>
											<dd>0</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				

					<li stream_id="4" class="block-live__list-item">
						<a id="hover-card-link-4" hovercard-id="4" hovercard-ref="streamHoverCards" class="block-live__link _hovertrigger" href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=4">
							<div class='block-live__list-item__online'>
								
									<img src='http://forums.undeadlords.net/public/style_images/Underground/rep_down.png' alt='-' />
								
							</div>
							<div class="block-live__list-item__viewers">0</div>
							<div class="block-live__list-item__name">Logan_Backshot_UDL</div>
						</a>
					</li>
					<div class='live-stream-4 block-live__tooltip popupWrapper' style='display: none;'>
						<div class='popupInner userpopup'>
							<h3><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=4">Logan_Backshot_UDL</a></h3>
							<div class='block-live__tooltip-preview side left ipsPad'>
								<div style='margin-bottom: 6px;'><img class='ipsUserPhoto' src='http://static-cdn.jtvnw.net/ttv-boxart/The Elder Scrolls Online.jpg' alt='The Elder Scrolls Online' title='The Elder Scrolls Online' /></div>
								<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class='rating ipsType_smaller'>
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star_off.png' alt='-' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star_off.png' alt='-' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star_off.png' alt='-' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star_off.png' alt='-' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star_off.png' alt='-' class='rate_img' />
									
								</span>
							</div>
							<div class='block-live__tooltip-right'>
								
									<div class='message' style='margin-bottom:5px;'>
										<div class='block-live__tooltip-status'>Leveling 1 - 10</div>
									</div>
								
								<div class="info">			
									<dl>
										<dt>Online For</dt>
											<dd>0</dd>
										<dt>Submitted by</dt>
											<dd>Lord Groone</dd>
										<dt>Comments</dt>
											<dd>0</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				

					<li stream_id="5" class="block-live__list-item">
						<a id="hover-card-link-5" hovercard-id="5" hovercard-ref="streamHoverCards" class="block-live__link _hovertrigger" href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=5">
							<div class='block-live__list-item__online'>
								
									<img src='http://forums.undeadlords.net/public/style_images/Underground/rep_down.png' alt='-' />
								
							</div>
							<div class="block-live__list-item__viewers">0</div>
							<div class="block-live__list-item__name">Groone</div>
						</a>
					</li>
					<div class='live-stream-5 block-live__tooltip popupWrapper' style='display: none;'>
						<div class='popupInner userpopup'>
							<h3><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=5">Groone</a></h3>
							<div class='block-live__tooltip-preview side left ipsPad'>
								<div style='margin-bottom: 6px;'><img class='ipsUserPhoto' src='http://static-cdn.jtvnw.net/ttv-boxart/Trove.jpg' alt='Trove' title='Trove' /></div>
								<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class='rating ipsType_smaller'>
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
								</span>
							</div>
							<div class='block-live__tooltip-right'>
								
									<div class='message' style='margin-bottom:5px;'>
										<div class='block-live__tooltip-status'>Doing a #Trove alpha for the first time.  </div>
									</div>
								
								<div class="info">			
									<dl>
										<dt>Online For</dt>
											<dd>0</dd>
										<dt>Submitted by</dt>
											<dd>Lord Groone</dd>
										<dt>Comments</dt>
											<dd>1</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				

					<li stream_id="6" class="block-live__list-item">
						<a id="hover-card-link-6" hovercard-id="6" hovercard-ref="streamHoverCards" class="block-live__link _hovertrigger" href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=6">
							<div class='block-live__list-item__online'>
								
									<img src='http://forums.undeadlords.net/public/style_images/Underground/rep_down.png' alt='-' />
								
							</div>
							<div class="block-live__list-item__viewers">0</div>
							<div class="block-live__list-item__name">Ryuseiju</div>
						</a>
					</li>
					<div class='live-stream-6 block-live__tooltip popupWrapper' style='display: none;'>
						<div class='popupInner userpopup'>
							<h3><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=livestreams&amp;showstream=6">Ryuseiju</a></h3>
							<div class='block-live__tooltip-preview side left ipsPad'>
								<div style='margin-bottom: 6px;'><img class='ipsUserPhoto' src='http://static-cdn.jtvnw.net/ttv-boxart/Magic: The Gathering.jpg' alt='Magic: The Gathering' title='Magic: The Gathering' /></div>
								<span itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating" class='rating ipsType_smaller'>
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
									
										<img src='http://forums.undeadlords.net/public/style_images/Underground/star.png' alt='*' class='rate_img' />
									
								</span>
							</div>
							<div class='block-live__tooltip-right'>
								
									<div class='message' style='margin-bottom:5px;'>
										<div class='block-live__tooltip-status'>Player of the Year Grind. Chat and Layout upgrades. Come in and say Hi!</div>
									</div>
								
								<div class="info">			
									<dl>
										<dt>Online For</dt>
											<dd>0</dd>
										<dt>Submitted by</dt>
											<dd>Lord Groone</dd>
										<dt>Comments</dt>
											<dd>0</dd>
									</dl>
								</div>
							</div>
						</div>
					</div>
				
			</ul>
		</div>
	</div>
	<script>
		var stream_hover_cards = {
			card: function(e, id){
				var id = id.replace(/hover-card-link-/, '' );
				return new Template($$('.live-stream-' + id)[0].innerHTML).evaluate();
			}
		};
		ipb.hoverCardRegister.initialize( 'streamHoverCards', { 'callback': stream_hover_cards.card, 'getId': true, 'delay': 750, 'position' : 'auto' } ); 
	</script>


<div class='ipsSideBlock clearfix'>
	<h3>Recent Topics</h3>
	<div class='_sbcollapsable'>
		<ul class='ipsList_withminiphoto'>
		
		<li class='clearfix'>
			
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3607.jpg?_r=1395858133' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

			<div class='list_content'>
				<strong><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22335" rel='bookmark' class='ipsType_small' title='Wheelz - ESO Application - started  Today, 10:56 AM'>Wheelz - ESO Application</a></strong>
				<p class='desc ipsType_smaller'>
					
	Wheelz

					- Today, 10:56 AM
				</p>
			</div>
		</li>
		

		<li class='clearfix'>
			
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3356.jpg?_r=1356494534' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

			<div class='list_content'>
				<strong><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22332" rel='bookmark' class='ipsType_small' title='Sofacouch - ESO application - started  Yesterday, 10:39 PM'>Sofacouch - ESO application</a></strong>
				<p class='desc ipsType_smaller'>
					
	Esponda

					- Yesterday, 10:39 PM
				</p>
			</div>
		</li>
		

		<li class='clearfix'>
			
	<div class='left'>

<img src='http://www.gravatar.com/avatar/9a6863a32b6ea28a94c556139da4c7a1?s=100&amp;d=http%3A%2F%2Fforums.undeadlords.net%2Fpublic%2Fstyle_images%2FUnderground%2Fprofile%2Fdefault_large.png' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

			<div class='list_content'>
				<strong><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22304" rel='bookmark' class='ipsType_small' title='BlakeH - ESO Application - started  23 March 2014 - 09:35 PM'>BlakeH - ESO Application</a></strong>
				<p class='desc ipsType_smaller'>
					
	BlakeH

					- Mar 23 2014 09:35 PM
				</p>
			</div>
		</li>
		

		<li class='clearfix'>
			
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3358.jpg?_r=1390090316' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

			<div class='list_content'>
				<strong><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22301" rel='bookmark' class='ipsType_small' title='If you ain&#39;t bought ESO yet - started  23 March 2014 - 07:51 PM'>If you ain&#39;t bought ESO yet</a></strong>
				<p class='desc ipsType_smaller'>
					
	Saurkor

					- Mar 23 2014 07:51 PM
				</p>
			</div>
		</li>
		

		<li class='clearfix'>
			
	<div class='left'>

<img src='http://forums.undeadlords.net/uploads/profile/photo-thumb-3593.gif?_r=1395811436' alt='Photo' class='ipsUserPhoto ipsUserPhoto_mini' />

	</div>

			<div class='list_content'>
				<strong><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;showtopic=22300" rel='bookmark' class='ipsType_small' title='New PC Build - Rip it apart... - started  23 March 2014 - 07:24 PM'>New PC Build - Rip it apart...</a></strong>
				<p class='desc ipsType_smaller'>
					
	Budikah

					- Mar 23 2014 07:24 PM
				</p>
			</div>
		</li>
		
		</ul>
	</div>
</div>
		</div>
		<a href='#' id='toggle_sidebar' title='' data-closed="&laquo;" data-open="&times;">&nbsp;</a>
</div>
<script type='text/javascript'>
//<![CDATA[
	var markerURL  = ipb.vars['base_url'] + "app=forums&module=ajax&section=markasread&i=1"; // Ajax URL so don't use &amp;
	var unreadIcon = "<img src='http://forums.undeadlords.net/public/style_images/Underground/f_icon_read.png' />";
	
	
		
			
				
					
				

					
				

					
				

					
				

					
				

					
				

					
				
			
		

			
				
					
				
			
		

			
				
					
				

					
				

					
				

					
				
			
		
	
//]]>
</script>

	<div id='board_stats'>		
		<ul class='ipsType_small ipsList_inline'>
			<li class='clear'>
				<span class='value'>87,144</span>
				Total Posts
			</li>
			<li class='clear'>
				<span class='value'>1,683</span>
				Total Members
			</li>
			<li class='clear'>
				<span class='value'>Wheelz</span>
				Newest Member
			</li>
			<li class='clear' data-tooltip="07 Mar 2014">
				<span class='value'>91</span>
				Most Online
			</li>
		</ul>
	</div>

<div id='board_statistics' class='statistics clearfix'>
	<h4 class='statistics_head'><ul id='stat_links' class='ipsList_inline right ipsType_small'>
		<!-- Hook point -->
			<li><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=forums&amp;module=extras&amp;section=stats&amp;do=leaders" title="View the moderating team">The Moderating Team</a></li>
			<li><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=forums&amp;module=extras&amp;section=stats" title="View today's top 20 posters">Today's Top Posters</a></li>
			<li><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=members&amp;module=list&amp;max_results=20&amp;sort_key=posts&amp;sort_order=desc&amp;filter=ALL" title="View the board&#39;s overall top posters">Overall Top Posters</a></li>
			<li>
				<a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=members&amp;module=reputation&amp;section=most">
				
					Most Liked Content
				
				</a>
			</li>
	</ul>
13 users are online (in the past 15 minutes)</h4>
	<p class='statistics_brief desc'>
		10 members, 3 guests, 0 anonymous users
		&nbsp;&nbsp;<a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=members&amp;module=online&amp;sort_order=desc'>(See full list)</a>
	</p>
	
	
		<br />
		<p>
			<span class='name'><span style='color:#FF9966'>Lord Xavier U-D-L</span>,</span> <span class='name'><span style='color:#99FF00'>Lord Groone</span>,</span> <span class='name'><span style='color:#66BB88'>DonkeyBoy</span>,</span> <span class='name'><span style='color:#66BB88'>headshot</span>,</span> <span class='name'><span style='color:yellow'>Savante</span>,</span> <span class='name'><span style='color:#99FF00'>Salina</span>,</span> <span class='name'><span style='color:#66BB88'>Budikah</span>,</span> <span class='name'><span style='color:#FF9966'>Terror</span>,</span> <span class='name'><span style='color:#FF00CC'>Google</span>,</span> <span class='name'><span style='color:#FF9966'>Droth</span>,</span> <span class='name'><span style='color:#FFCC00'>Kick</span>
		</p>
	
</div>
				
				<ol class='breadcrumb bottom ipsList_inline left clearfix clear'>
					
						<li>&nbsp;</li>
					
				</ol>
			</div>
			<div class='branding_skin'>
<a href="http://www.skinbox.net/" title="IPB Skins and Invision Skins at Skinbox"><strong>IPB skins</strong></a> by <a href="http://www.skinbox.net/" title="IPB Skins and Invision Skins at Skinbox"><strong>Skinbox</strong></a>
<a href="http://www.skinbox.net" title="IPB Skins at Skinbox"><img src="http://forums.undeadlords.net/public/style_images/Underground/_custom/skinbox.png" class="branding_logo" alt="IPB Skins at Skinbox" /></a>
</div>
			<!-- ::: FOOTER (Change skin, language, mark as read, etc) ::: -->
			<div id='footer_utilities' class='clearfix clear'>
				<a rel="nofollow" href='#top' id='backtotop' title='Go to top'><img src='http://forums.undeadlords.net/public/style_images/Underground/top.png' alt='' /></a>
				<!-- Copyright Information -->
        				  <p id='copyright'>
        				  	<a href='http://www.invisionpower.com/apps/board/' title='Community Forum Software by Invision Power Services'>Community Forum Software by IP.Board</a><br />Licensed to: The Undead Lords</p>
		<!-- / Copyright -->
				<ul class='ipsList_inline left'>
					<li>
						<img src='http://forums.undeadlords.net/public/style_images/Underground/feed.png' alt='RSS Feed' id='rss_feed' class='clickable' />
					</li>
					
						
					
					
					<li><a rel="nofollow" href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=privacy'>Privacy Policy</a></li>
					<li>
						<a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=help" title='View help' rel="help" accesskey='6'>Help</a>
					</li>				
				</ul>
			</div>
			
			<div id='stats_div'><div><img src='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=task' alt='' style='border: 0px;height:1px;width:1px;' /></div></div>
			
				<script type="text/javascript">
					ipb.global.lightBoxIsOff();
				</script>
			

</div>

		</div>
		</div></div></div>
		
<div id='inline_login_form' class='sb_login' style='display: none'>
		<form action="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=login&amp;do=process" method="post" id='login'>
			<input type='hidden' name='auth_key' value='880ea6a14ea49e853634fbdc5015a024' />
			<input type="hidden" name="referer" value="http://forums.undeadlords.net/index.php?act=task" />
			<h3>Sign In</h3>
			<div class='ipsBox_notice'>
					<ul class='ipsList_inline'>
						
							<li><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=login&amp;serviceClick=facebook" class='ipsButton_secondary'><img src="http://forums.undeadlords.net/public/style_images/Underground/loginmethods/facebook.png" alt="Facebook" /> &nbsp; Use Facebook</a></li>
						
						
						
					</ul>
				</div>
			
            <div class='sb_login_row'>

                <div class='sb_login_col'>
                    <span class='right desc lighter blend_links'><a href="http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=register" title='Register now!'>Register now!</a></span>
            		<strong><label for='ips_username'>Username</label></strong>
                    <div class='ipsField_content'>
                    	<input id='ips_username' type='text' class='input_text sb_login_input sb_luser' name='ips_username' placeholder="Username" size='30' tabindex='1' />
                    </div>
                </div>
                
                <div class='sb_login_col'>
                    <span class='right desc lighter blend_links'><a href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=lostpass' title='Retrieve password'>I've forgotten my password</a></span>
                    <strong><label for='ips_password'>Password</label></strong>
                    <div class='ipsField_content'>
                        <input id='ips_password' type='password' class='input_text sb_login_input sb_lpassword' name='ips_password' placeholder="Password" size='30' tabindex='2' /><br />
                    </div>
                </div>
        
            </div>
            
            <div class='clearfix'>
        
                <div class='sb_login_col'>
                    <input type='checkbox' id='inline_remember' checked='checked' name='rememberMe' value='1' class='input_check left' />
                    <div style='padding-left: 20px;'>
                        <label for='inline_remember'>
                            <strong>Remember me</strong>
                            <span class='desc lighter' style='display: block; padding-top: 5px;'>This is not recommended for shared computers</span>
                        </label>
                    </div>
                </div>
    
                
    
            </div>

                        <div class='ipsPad ipsForm_center desc ipsType_smaller'>
                            <a rel="nofollow" href='http://forums.undeadlords.net/index.php?s=4706588342511bb6d5e4db3cb505f0d8&amp;app=core&amp;module=global&amp;section=privacy'>Privacy Policy</a>
                        </div>
                        
            
            <div class='ipsForm_submit ipsForm_center clear'>
                <input type='submit' class='input_submit' value='Sign In' tabindex='3' />
            </div>

		</form>
	</div>

        <script type='text/javascript'>
            // if( $('primary_nav') ){    ipb.global.activateMainMenu(); }
        </script>
        

	</body>
</html>